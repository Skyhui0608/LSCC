package com.ainirobot.robotos.maputils;

/**
 * Created by Orion on 2019/3/15.
 */

public class UnchangeableString {

    public static final String RECEPTION_POINT = "接待点";
    public static final String STAND_BY_SPOT = "待机点";
    public static final String POSITIONING_SPOT = "定位点";
}
