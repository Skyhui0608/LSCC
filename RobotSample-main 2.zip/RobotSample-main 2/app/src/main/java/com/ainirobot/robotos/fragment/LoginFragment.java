package com.ainirobot.robotos.fragment;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.ainirobot.robotos.R;
import com.ainirobot.robotos.utils.UserManager;

/**
 * 登錄Fragment
 */
public class LoginFragment extends BaseFragment {

    private EditText etUsername;
    private EditText etPassword;
    private Button btnLogin;
    private Button btnRegister;
    private UserManager userManager;

    @Override
    public View onCreateView(Context context) {
        View root = mInflater.inflate(R.layout.fragment_login_layout, null, false);
        bindViews(root);
        hideBackView();
        hideResultView();
        
        // 初始化用戶管理器
        userManager = UserManager.getInstance(getActivity());
        
        // 如果已經登錄，直接跳轉到主頁面
        if (userManager.isLoggedIn()) {
            switchFragment(MainFragment.newInstance());
        }
        
        return root;
    }

    private void bindViews(View root) {
        etUsername = root.findViewById(R.id.et_username);
        etPassword = root.findViewById(R.id.et_password);
        btnLogin = root.findViewById(R.id.btn_login);
        btnRegister = root.findViewById(R.id.btn_register);

        // 登錄按鈕點擊事件
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performLogin();
            }
        });

        // 註冊按鈕點擊事件
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchFragment(RegisterFragment.newInstance());
            }
        });
    }

    /**
     * 執行登錄
     */
    private void performLogin() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        // 驗證輸入
        if (TextUtils.isEmpty(username)) {
            Toast.makeText(getActivity(), getString(R.string.username_empty), Toast.LENGTH_SHORT).show();
            etUsername.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            Toast.makeText(getActivity(), getString(R.string.password_empty), Toast.LENGTH_SHORT).show();
            etPassword.requestFocus();
            return;
        }

        // 執行登錄
        boolean loginSuccess = userManager.loginUser(username, password);
        
        if (loginSuccess) {
            Toast.makeText(getActivity(), getString(R.string.login_success), Toast.LENGTH_SHORT).show();
            // 登錄成功，跳轉到主頁面
            switchFragment(MainFragment.newInstance());
        } else {
            Toast.makeText(getActivity(), getString(R.string.login_failed), Toast.LENGTH_SHORT).show();
        }
    }

    public static Fragment newInstance() {
        return new LoginFragment();
    }
} 