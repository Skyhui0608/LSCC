/*
 *  Copyright (C) 2017 OrionStar Technology Project
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package com.ainirobot.robotos;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import android.widget.TextView;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.os.Handler;


import com.ainirobot.coreservice.client.RobotApi;
import com.ainirobot.robotos.fragment.FailedFragment;
import com.ainirobot.robotos.fragment.LoginFragment;
import com.ainirobot.robotos.fragment.MainFragment;
import com.ainirobot.robotos.utils.UserManager;

public class MainActivity extends AppCompatActivity {

    private FrameLayout mContent;

    private static MainActivity mInstance;
    private int checkTimes;

    public static MainActivity getInstance(){
        return mInstance;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 检查是否通过 URL scheme 打开应用
        Intent intent = getIntent();
        if (intent != null && intent.getData() != null && intent.getData().getScheme().equals("jerry")) {
            String scheme = intent.getData().getScheme();
            String host = intent.getData().getHost();
            String path = intent.getData().getPath();

            if (host != null && host.equals("main")) {
                // 打开与用户在Launcher上手动点击图标打开的页面相同的效果
                setContentView(R.layout.activity_main);
                initViews();
                mInstance = MainActivity.this;
                return;
            }
        }

        // 默认的启动逻辑
        setContentView(R.layout.splash_layout);
        TextView textSplash = findViewById(R.id.text_splash);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                checkTimes = 0;
                setContentView(R.layout.activity_main);
                initViews();
                mInstance = MainActivity.this;
            }
        }, 1200); // 延迟执行checkInit()
    }


    private void initViews() {
        mContent = findViewById(R.id.container_content);
        checkInit();
    }

    public void switchFragment(Fragment fragment){

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container_content, fragment, fragment.getClass().getName())
                .commit();
    }

    private void checkInit(){
        checkTimes++;
        if(checkTimes > 10){
            Fragment fragment = FailedFragment.newInstance();
            switchFragment(fragment);
        }
        else if(RobotApi.getInstance().isApiConnectedService()
                && RobotApi.getInstance().isActive()){
            
            // 檢查登錄狀態
            UserManager userManager = UserManager.getInstance(this);
            if (userManager.isLoggedIn()) {
                // 已登錄，跳轉到主頁面
                Fragment fragment = MainFragment.newInstance();
                switchFragment(fragment);
            } else {
                // 未登錄，跳轉到登錄頁面
                Fragment fragment = LoginFragment.newInstance();
                switchFragment(fragment);
            }
        }else
        {
            mContent.postDelayed(new Runnable() {
                @Override
                public void run() {
                    // 继续显示Splash界面

                    checkInit();
                }
            },300);
        }
    }
}
