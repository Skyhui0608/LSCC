package com.ainirobot.robotos.fragment;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.ainirobot.robotos.R;
import com.ainirobot.robotos.utils.UserManager;

/**
 * 註冊Fragment
 */
public class RegisterFragment extends BaseFragment {

    private EditText etUsername;
    private EditText etPassword;
    private EditText etConfirmPassword;
    private EditText etEmail;
    private EditText etPhone;
    private Button btnRegister;
    private Button btnBackToLogin;
    private UserManager userManager;

    @Override
    public View onCreateView(Context context) {
        View root = mInflater.inflate(R.layout.fragment_register_layout, null, false);
        bindViews(root);
        showBackView();
        hideResultView();
        
        // 初始化用戶管理器
        userManager = UserManager.getInstance(getActivity());
        
        return root;
    }

    private void bindViews(View root) {
        etUsername = root.findViewById(R.id.et_username);
        etPassword = root.findViewById(R.id.et_password);
        etConfirmPassword = root.findViewById(R.id.et_confirm_password);
        etEmail = root.findViewById(R.id.et_email);
        etPhone = root.findViewById(R.id.et_phone);
        btnRegister = root.findViewById(R.id.btn_register);
        btnBackToLogin = root.findViewById(R.id.btn_back_to_login);

        // 註冊按鈕點擊事件
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performRegister();
            }
        });

        // 返回登錄按鈕點擊事件
        btnBackToLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchFragment(LoginFragment.newInstance());
            }
        });
    }

    /**
     * 執行註冊
     */
    private void performRegister() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String confirmPassword = etConfirmPassword.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();

        // 驗證輸入
        if (TextUtils.isEmpty(username)) {
            Toast.makeText(getActivity(), getString(R.string.username_empty), Toast.LENGTH_SHORT).show();
            etUsername.requestFocus();
            return;
        }

        if (username.length() < 3 || username.length() > 20) {
            Toast.makeText(getActivity(), "用戶名長度應為3-20個字符", Toast.LENGTH_SHORT).show();
            etUsername.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            Toast.makeText(getActivity(), getString(R.string.password_empty), Toast.LENGTH_SHORT).show();
            etPassword.requestFocus();
            return;
        }

        if (password.length() < 6) {
            Toast.makeText(getActivity(), "密碼至少需要6個字符", Toast.LENGTH_SHORT).show();
            etPassword.requestFocus();
            return;
        }

        if (!password.equals(confirmPassword)) {
            Toast.makeText(getActivity(), getString(R.string.password_not_match), Toast.LENGTH_SHORT).show();
            etConfirmPassword.requestFocus();
            return;
        }

        // 驗證電子郵件格式
        if (!TextUtils.isEmpty(email) && !userManager.isValidEmail(email)) {
            Toast.makeText(getActivity(), getString(R.string.email_invalid), Toast.LENGTH_SHORT).show();
            etEmail.requestFocus();
            return;
        }

        // 驗證手機號碼格式
        if (!TextUtils.isEmpty(phone) && !userManager.isValidPhone(phone)) {
            Toast.makeText(getActivity(), getString(R.string.phone_invalid), Toast.LENGTH_SHORT).show();
            etPhone.requestFocus();
            return;
        }

        // 檢查用戶是否已存在
        if (userManager.isUserExists(username)) {
            Toast.makeText(getActivity(), getString(R.string.user_already_exists), Toast.LENGTH_SHORT).show();
            etUsername.requestFocus();
            return;
        }

        // 執行註冊
        boolean registerSuccess = userManager.registerUser(username, password, email, phone);
        
        if (registerSuccess) {
            Toast.makeText(getActivity(), getString(R.string.register_success), Toast.LENGTH_SHORT).show();
            // 註冊成功，返回登錄頁面
            switchFragment(LoginFragment.newInstance());
        } else {
            Toast.makeText(getActivity(), getString(R.string.register_failed), Toast.LENGTH_SHORT).show();
        }
    }

    public static Fragment newInstance() {
        return new RegisterFragment();
    }
} 