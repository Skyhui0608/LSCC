package com.ainirobot.robotos.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import android.util.Log;

import com.ainirobot.robotos.model.User;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * 用戶管理工具類
 */
public class UserManager {
    private static final String TAG = "UserManager";
    private static final String PREF_NAME = "user_preferences";
    private static final String KEY_USERS = "users";
    private static final String KEY_CURRENT_USER = "current_user";
    
    private static UserManager instance;
    private SharedPreferences preferences;
    private Gson gson;
    private List<User> users;
    private User currentUser;
    
    // 正則表達式
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
            "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    private static final Pattern PHONE_PATTERN = Pattern.compile(
            "^1[3-9]\\d{9}$");

    private UserManager(Context context) {
        preferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        gson = new Gson();
        loadUsers();
        loadCurrentUser();
    }

    public static synchronized UserManager getInstance(Context context) {
        if (instance == null) {
            instance = new UserManager(context.getApplicationContext());
        }
        return instance;
    }

    /**
     * 載入用戶列表
     */
    private void loadUsers() {
        String usersJson = preferences.getString(KEY_USERS, "[]");
        Type type = new TypeToken<ArrayList<User>>(){}.getType();
        users = gson.fromJson(usersJson, type);
        if (users == null) {
            users = new ArrayList<>();
        }
        
        // 如果沒有用戶，創建一個默認管理員賬戶
        if (users.isEmpty()) {
            User adminUser = new User("admin", "admin123", "admin@robot.com", "13800138000");
            users.add(adminUser);
            saveUsers();
        }
    }

    /**
     * 保存用戶列表
     */
    private void saveUsers() {
        String usersJson = gson.toJson(users);
        preferences.edit().putString(KEY_USERS, usersJson).apply();
    }

    /**
     * 載入當前用戶
     */
    private void loadCurrentUser() {
        String currentUserJson = preferences.getString(KEY_CURRENT_USER, null);
        if (!TextUtils.isEmpty(currentUserJson)) {
            currentUser = gson.fromJson(currentUserJson, User.class);
        }
    }

    /**
     * 保存當前用戶
     */
    private void saveCurrentUser() {
        if (currentUser != null) {
            String currentUserJson = gson.toJson(currentUser);
            preferences.edit().putString(KEY_CURRENT_USER, currentUserJson).apply();
        } else {
            preferences.edit().remove(KEY_CURRENT_USER).apply();
        }
    }

    /**
     * 用戶註冊
     */
    public boolean registerUser(String username, String password, String email, String phone) {
        // 驗證輸入
        if (!validateRegistrationInput(username, password, email, phone)) {
            return false;
        }

        // 檢查用戶是否已存在
        if (isUserExists(username)) {
            Log.w(TAG, "User already exists: " + username);
            return false;
        }

        // 創建新用戶
        User newUser = new User(username, password, email, phone);
        users.add(newUser);
        saveUsers();
        
        Log.i(TAG, "User registered successfully: " + username);
        return true;
    }

    /**
     * 用戶登錄
     */
    public boolean loginUser(String username, String password) {
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Log.w(TAG, "Username or password is empty");
            return false;
        }

        // 查找用戶
        User user = findUserByUsername(username);
        if (user == null) {
            Log.w(TAG, "User not found: " + username);
            return false;
        }

        // 驗證密碼
        if (!password.equals(user.getPassword())) {
            Log.w(TAG, "Password incorrect for user: " + username);
            return false;
        }

        // 更新最後登錄時間
        user.setLastLoginTime(System.currentTimeMillis());
        currentUser = user;
        saveCurrentUser();
        saveUsers();
        
        Log.i(TAG, "User logged in successfully: " + username);
        return true;
    }

    /**
     * 用戶登出
     */
    public void logoutUser() {
        currentUser = null;
        saveCurrentUser();
        Log.i(TAG, "User logged out");
    }

    /**
     * 檢查用戶是否存在
     */
    public boolean isUserExists(String username) {
        return findUserByUsername(username) != null;
    }

    /**
     * 根據用戶名查找用戶
     */
    public User findUserByUsername(String username) {
        for (User user : users) {
            if (username.equals(user.getUsername())) {
                return user;
            }
        }
        return null;
    }

    /**
     * 獲取當前登錄用戶
     */
    public User getCurrentUser() {
        return currentUser;
    }

    /**
     * 檢查是否已登錄
     */
    public boolean isLoggedIn() {
        return currentUser != null;
    }

    /**
     * 獲取所有用戶
     */
    public List<User> getAllUsers() {
        return new ArrayList<>(users);
    }

    /**
     * 刪除用戶
     */
    public boolean deleteUser(String username) {
        User userToDelete = findUserByUsername(username);
        if (userToDelete == null) {
            return false;
        }

        // 不能刪除當前登錄用戶
        if (currentUser != null && username.equals(currentUser.getUsername())) {
            return false;
        }

        users.remove(userToDelete);
        saveUsers();
        Log.i(TAG, "User deleted: " + username);
        return true;
    }

    /**
     * 更新用戶信息
     */
    public boolean updateUser(String username, String email, String phone) {
        User user = findUserByUsername(username);
        if (user == null) {
            return false;
        }

        user.setEmail(email);
        user.setPhone(phone);
        saveUsers();
        
        // 如果是當前用戶，也要更新當前用戶信息
        if (currentUser != null && username.equals(currentUser.getUsername())) {
            currentUser.setEmail(email);
            currentUser.setPhone(phone);
            saveCurrentUser();
        }
        
        Log.i(TAG, "User updated: " + username);
        return true;
    }

    /**
     * 驗證註冊輸入
     */
    private boolean validateRegistrationInput(String username, String password, String email, String phone) {
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Log.w(TAG, "Username or password is empty");
            return false;
        }

        if (username.length() < 3 || username.length() > 20) {
            Log.w(TAG, "Username length should be between 3 and 20 characters");
            return false;
        }

        if (password.length() < 6) {
            Log.w(TAG, "Password should be at least 6 characters");
            return false;
        }

        if (!TextUtils.isEmpty(email) && !EMAIL_PATTERN.matcher(email).matches()) {
            Log.w(TAG, "Invalid email format");
            return false;
        }

        if (!TextUtils.isEmpty(phone) && !PHONE_PATTERN.matcher(phone).matches()) {
            Log.w(TAG, "Invalid phone format");
            return false;
        }

        return true;
    }

    /**
     * 驗證電子郵件格式
     */
    public boolean isValidEmail(String email) {
        return !TextUtils.isEmpty(email) && EMAIL_PATTERN.matcher(email).matches();
    }

    /**
     * 驗證手機號碼格式
     */
    public boolean isValidPhone(String phone) {
        return !TextUtils.isEmpty(phone) && PHONE_PATTERN.matcher(phone).matches();
    }
} 