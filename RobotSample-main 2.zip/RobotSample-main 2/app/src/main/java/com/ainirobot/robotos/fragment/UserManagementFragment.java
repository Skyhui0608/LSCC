package com.ainirobot.robotos.fragment;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.ainirobot.robotos.R;
import com.ainirobot.robotos.model.User;
import com.ainirobot.robotos.utils.UserManager;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * 用戶管理Fragment
 */
public class UserManagementFragment extends BaseFragment {

    private TextView tvCurrentUserInfo;
    private LinearLayout llUserList;
    private Button btnAddUser;
    private Button btnRefresh;
    private UserManager userManager;

    @Override
    public View onCreateView(Context context) {
        View root = mInflater.inflate(R.layout.fragment_user_management_layout, null, false);
        bindViews(root);
        showBackView();
        hideResultView();
        
        // 初始化用戶管理器
        userManager = UserManager.getInstance(getActivity());
        
        // 更新界面
        updateCurrentUserInfo();
        updateUserList();
        
        return root;
    }

    private void bindViews(View root) {
        tvCurrentUserInfo = root.findViewById(R.id.tv_current_user_info);
        llUserList = root.findViewById(R.id.ll_user_list);
        btnAddUser = root.findViewById(R.id.btn_add_user);
        btnRefresh = root.findViewById(R.id.btn_refresh);

        // 添加用戶按鈕點擊事件
        btnAddUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchFragment(RegisterFragment.newInstance());
            }
        });

        // 刷新按鈕點擊事件
        btnRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateUserList();
                Toast.makeText(getActivity(), "已刷新", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * 更新當前用戶信息
     */
    private void updateCurrentUserInfo() {
        User currentUser = userManager.getCurrentUser();
        if (currentUser != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            String lastLoginTime = sdf.format(new Date(currentUser.getLastLoginTime()));
            
            String userInfo = String.format("當前用戶：%s\n電子郵件：%s\n手機號碼：%s\n最後登錄：%s",
                    currentUser.getUsername(),
                    currentUser.getEmail() != null ? currentUser.getEmail() : "未設置",
                    currentUser.getPhone() != null ? currentUser.getPhone() : "未設置",
                    lastLoginTime);
            
            tvCurrentUserInfo.setText(userInfo);
        }
    }

    /**
     * 更新用戶列表
     */
    private void updateUserList() {
        llUserList.removeAllViews();
        
        List<User> users = userManager.getAllUsers();
        User currentUser = userManager.getCurrentUser();
        
        for (User user : users) {
            View userItemView = createUserItemView(user, currentUser);
            llUserList.addView(userItemView);
        }
    }

    /**
     * 創建用戶項目視圖
     */
    private View createUserItemView(final User user, User currentUser) {
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.item_user, null);
        
        TextView tvUsername = view.findViewById(R.id.tv_username);
        TextView tvEmail = view.findViewById(R.id.tv_email);
        TextView tvPhone = view.findViewById(R.id.tv_phone);
        TextView tvCreateTime = view.findViewById(R.id.tv_create_time);
        Button btnDelete = view.findViewById(R.id.btn_delete);
        
        // 設置用戶信息
        tvUsername.setText("用戶名：" + user.getUsername());
        tvEmail.setText("電子郵件：" + (user.getEmail() != null ? user.getEmail() : "未設置"));
        tvPhone.setText("手機號碼：" + (user.getPhone() != null ? user.getPhone() : "未設置"));
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        String createTime = sdf.format(new Date(user.getCreateTime()));
        tvCreateTime.setText("創建時間：" + createTime);
        
        // 如果是當前用戶，禁用刪除按鈕
        if (currentUser != null && user.getUsername().equals(currentUser.getUsername())) {
            btnDelete.setEnabled(false);
            btnDelete.setText("當前用戶");
        } else {
            btnDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    deleteUser(user);
                }
            });
        }
        
        return view;
    }

    /**
     * 刪除用戶
     */
    private void deleteUser(User user) {
        boolean success = userManager.deleteUser(user.getUsername());
        if (success) {
            Toast.makeText(getActivity(), "用戶 " + user.getUsername() + " 已刪除", Toast.LENGTH_SHORT).show();
            updateUserList();
        } else {
            Toast.makeText(getActivity(), "刪除失敗", Toast.LENGTH_SHORT).show();
        }
    }

    public static Fragment newInstance() {
        return new UserManagementFragment();
    }
} 